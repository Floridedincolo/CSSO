﻿// P3.cpp - versiune actualizata: creeaza shared mapping, porneste P1, asteapta P1, porneste P2,
// asteapta P2 sa scrie PID-urile in memoria partajata, preia PID-urile si genereaza sumar.

#include <iostream>
#include <windows.h>
#include <algorithm>
#include <stdio.h>
#include <string.h>
#include <vector>
#include <tlhelp32.h>
#include <sddl.h>      
#pragma comment(lib, "version.lib")
#pragma comment(lib, "bcrypt.lib")
#define _CRT_SECURE_NO_WARNINGS
#define MAX_SIZE 1024

using namespace std;

vector<int> pids;
vector<string> openStatus;

bool DumpTokenInfo(HANDLE hProcess, const char* outPath) {
    HANDLE hToken = NULL;
    if (!OpenProcessToken(hProcess, TOKEN_QUERY, &hToken)) {

        return false;
    }

    HANDLE hFile = CreateFileA(outPath, GENERIC_WRITE, FILE_SHARE_READ, NULL,
        CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) {
        CloseHandle(hToken);
        return false;
    }

    DWORD written = 0;
    char buf[1024];

    // TOKEN_USER
    DWORD needed = 0;
    GetTokenInformation(hToken, TokenUser, NULL, 0, &needed);
    if (needed > 0) {
        PTOKEN_USER pUser = (PTOKEN_USER)LocalAlloc(LPTR, needed);
        if (pUser && GetTokenInformation(hToken, TokenUser, pUser, needed, &needed)) {
            LPSTR sidStr = NULL;
            if (ConvertSidToStringSidA(pUser->User.Sid, &sidStr)) {
                int n = snprintf(buf, sizeof(buf), "User SID=%s\r\n", sidStr);
                WriteFile(hFile, buf, n, &written, NULL);
                LocalFree(sidStr);
            }
        }
        if (pUser) LocalFree(pUser);
    }

    // TOKEN_ELEVATION
    TOKEN_ELEVATION te = { 0 }; DWORD ret = 0;
    if (GetTokenInformation(hToken, TokenElevation, &te, sizeof(te), &ret)) {
        int n = snprintf(buf, sizeof(buf), "Elevation: %s\r\n", te.TokenIsElevated ? "Elevated" : "Not elevated");
        WriteFile(hFile, buf, n, &written, NULL);
    }

    // Integrity level
    needed = 0;
    GetTokenInformation(hToken, TokenIntegrityLevel, NULL, 0, &needed);
    if (needed > 0) {
        PTOKEN_MANDATORY_LABEL pIL = (PTOKEN_MANDATORY_LABEL)LocalAlloc(LPTR, needed);
        if (pIL && GetTokenInformation(hToken, TokenIntegrityLevel, pIL, needed, &needed)) {
            DWORD integrityRid = *GetSidSubAuthority(pIL->Label.Sid,
                (DWORD)(*GetSidSubAuthorityCount(pIL->Label.Sid) - 1));
            const char* level = "Unknown";
            if (integrityRid == SECURITY_MANDATORY_LOW_RID) level = "Low";
            else if (integrityRid >= SECURITY_MANDATORY_MEDIUM_RID && integrityRid < SECURITY_MANDATORY_HIGH_RID) level = "Medium";
            else if (integrityRid >= SECURITY_MANDATORY_HIGH_RID && integrityRid < SECURITY_MANDATORY_SYSTEM_RID) level = "High";
            else if (integrityRid >= SECURITY_MANDATORY_SYSTEM_RID) level = "System";

            int n = snprintf(buf, sizeof(buf), "Integrity: %s\r\n", level);
            WriteFile(hFile, buf, n, &written, NULL);
        }
        if (pIL) LocalFree(pIL);
    }

    // Privileges
    needed = 0;
    GetTokenInformation(hToken, TokenPrivileges, NULL, 0, &needed);
    if (needed > 0) {
        PTOKEN_PRIVILEGES pPriv = (PTOKEN_PRIVILEGES)LocalAlloc(LPTR, needed);
        if (pPriv && GetTokenInformation(hToken, TokenPrivileges, pPriv, needed, &needed)) {
            WriteFile(hFile, "Active privileges:\r\n", 20, &written, NULL);
            for (DWORD i = 0; i < pPriv->PrivilegeCount; ++i) {
                LUID_AND_ATTRIBUTES la = pPriv->Privileges[i];
                CHAR name[256]; DWORD nameLen = sizeof(name);
                if (LookupPrivilegeNameA(NULL, &la.Luid, name, &nameLen)) {
                    int enabled = (la.Attributes & SE_PRIVILEGE_ENABLED) != 0;
                    int n = snprintf(buf, sizeof(buf), "  %s : %s\r\n", name, enabled ? "ENABLED" : "DISABLED");
                    WriteFile(hFile, buf, n, &written, NULL);
                }
            }
        }
        if (pPriv) LocalFree(pPriv);
    }

    CloseHandle(hToken);
    CloseHandle(hFile);
    return true;
}

bool canOpenProcess(DWORD pid) {
    if (pid == 0) return false;
    HANDLE hProc = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, pid);
    if (hProc) { CloseHandle(hProc); return true; }
    return false;
}

void readPIDsFromSharedMemory(char* sharedMem, vector<int>& pidList) {
    if (!sharedMem) return;
    char* p = sharedMem + 1;
    pidList.clear();
    while (*p != 0) {
        while (*p == ' ') ++p;
        if (*p == 0) break;
        int pid = 0;
        bool any = false;
        while (*p >= '0' && *p <= '9') {
            pid = pid * 10 + (*p - '0');
            ++p;
            any = true;
        }
        if (any) pidList.push_back(pid);
        while (*p == ' ') ++p;
    }
}
void createDirectories(const char* fullPath) {
    char auxPath[MAX_SIZE];
    char currentPath[MAX_SIZE] = "";
    strcpy(auxPath, fullPath);
    char* p = strtok(auxPath, "\\");
    while (p != NULL) {
        strcat(currentPath, p);
        CreateDirectoryA(currentPath, NULL);
        strcat(currentPath, "\\");
        p = strtok(NULL, "\\");
    }
}
void createSummary(const vector<int>& pidList) {
    createDirectories("C:\\Facultate\\CSSO\\Laboratoare\\H3\\Raport");
   createDirectories("C:\\Facultate\\CSSO\\Laboratoare\\H3\\Detalii");
    HANDLE hFile = CreateFileA("C:\\Facultate\\CSSO\\Laboratoare\\H3\\Raport\\sumar.txt",
        GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) {
        printf("Eroare la creare raport sumar (%lu)\n", GetLastError());
        return;
    }

    DWORD written;
    char buf[1024];

    sprintf(buf, "- Lista programelor deschise a fost salvata in procese.txt.\r\n");
    WriteFile(hFile, buf, strlen(buf), &written, NULL);

    sprintf(buf, "- PID-urile celor 5 programe analizate: ");
    WriteFile(hFile, buf, strlen(buf), &written, NULL);
    for (int pid : pidList) {
        sprintf(buf, "%d ", pid);
        WriteFile(hFile, buf, strlen(buf), &written, NULL);
    }
    WriteFile(hFile, "\r\n", 2, &written, NULL);

    for (size_t i = 0; i < pidList.size(); ++i) {
        int pid = pidList[i];
        char path[MAX_SIZE];
        sprintf(path, "C:\\Facultate\\CSSO\\Laboratoare\\H3\\Detalii\\%d.txt", pid);
        HANDLE fh = CreateFileA(path, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
        if (fh == INVALID_HANDLE_VALUE) {
            sprintf(buf, "Programul %d: are 0 parti incarcate si 0 fire de lucru. Se poate deschide: %s\r\n",
                pid, (i < openStatus.size() ? openStatus[i].c_str() : "NU"));
            WriteFile(hFile, buf, strlen(buf), &written, NULL);
            continue;
        }

        int moduleCount = 0, threadCount = 0;
        string currentLine;
        char ch;
        DWORD bytesRead;
        while (ReadFile(fh, &ch, 1, &bytesRead, NULL) && bytesRead > 0) {
            if (ch != '\n') currentLine += ch;
            else {
                if (currentLine.rfind("THREAD:", 0) == 0) threadCount++;
                else moduleCount++;
                currentLine.clear();
            }
        }
        CloseHandle(fh);

        sprintf(buf, "Programul %d: are %d parti incarcate si %d fire de lucru. Se poate deschide: %s\r\n",
            pid, moduleCount, threadCount, (i < openStatus.size() ? openStatus[i].c_str() : "NU"));
        WriteFile(hFile, buf, strlen(buf), &written, NULL);
    }

    const char* tokens[2] = { "token_P1.txt", "token_P2.txt" };
    const char* names[2] = { "P1.exe", "P2.exe" };
    for (int i = 0; i < 2; ++i) {
        char path[MAX_SIZE];
        sprintf(path, "C:\\Facultate\\CSSO\\Laboratoare\\H3\\%s", tokens[i]);
        HANDLE fh = CreateFileA(path, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
        if (fh == INVALID_HANDLE_VALUE) continue;

        sprintf(buf, "%s:\r\n", names[i]);
        WriteFile(hFile, buf, strlen(buf), &written, NULL);

        DWORD bytes;
        while (ReadFile(fh, buf, sizeof(buf), &bytes, NULL) && bytes > 0) {
            WriteFile(hFile, buf, bytes, &written, NULL);
        }
        CloseHandle(fh);
        WriteFile(hFile, "\r\n", 2, &written, NULL);
    }

    CloseHandle(hFile);
}

void P3_main() {
    HANDLE sharedMemoryH = CreateFileMappingA(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0, 1024, "CSSOH3");
    if (!sharedMemoryH) return;

    char* sharedVirtualMem = (char*)MapViewOfFile(sharedMemoryH, FILE_MAP_ALL_ACCESS, 0, 0, 0);
    if (!sharedVirtualMem) {
        CloseHandle(sharedMemoryH);
        return;
    }

    memset(sharedVirtualMem, 0, 1024);

    STARTUPINFOA si = { sizeof(si) };
    PROCESS_INFORMATION pi1 = { 0 }, pi2 = { 0 };

    if (!CreateProcessA("C:\\Users\\teo\\source\\repos\\P1\\ARM64\\Debug\\P1.exe",
        NULL, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi1))
    {
        UnmapViewOfFile(sharedVirtualMem);
        CloseHandle(sharedMemoryH);
        return;
    }

    WaitForSingleObject(pi1.hProcess, INFINITE);
    Sleep(200);

    if (!CreateProcessA("C:\\Users\\teo\\source\\repos\\P2\\ARM64\\Debug\\P2.exe",
        NULL, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi2))
    {
        CloseHandle(pi1.hThread);
        CloseHandle(pi1.hProcess);
        UnmapViewOfFile(sharedVirtualMem);
        CloseHandle(sharedMemoryH);
        return;
    }

    const int maxWaitMs = 5000;
    const int pollIntervalMs = 100;
    int waited = 0;
    while (sharedVirtualMem[0] == 0 && waited < maxWaitMs) {
        Sleep(pollIntervalMs);
        waited += pollIntervalMs;
    }

    readPIDsFromSharedMemory(sharedVirtualMem, pids);

    openStatus.clear();
    for (int pid : pids)
        openStatus.push_back(canOpenProcess(pid) ? "DA" : "NU");

    DumpTokenInfo(pi1.hProcess, "C:\\Facultate\\CSSO\\Laboratoare\\H3\\token_P1.txt");
    DumpTokenInfo(pi2.hProcess, "C:\\Facultate\\CSSO\\Laboratoare\\H3\\token_P2.txt");

    DWORD pidP1 = pi1.dwProcessId;
    HANDLE hP1 = OpenProcess(PROCESS_TERMINATE, FALSE, pidP1);
    if (hP1) {
        TerminateProcess(hP1, 1);
        WaitForSingleObject(hP1, INFINITE);
        CloseHandle(hP1);
        printf("Procesul P1.exe cu PID %lu a fost terminat fortat.\n", pidP1);
    }

    bool exists = false;
    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnap != INVALID_HANDLE_VALUE) {
        PROCESSENTRY32 pe;
        ZeroMemory(&pe, sizeof(pe));
        pe.dwSize = sizeof(pe);

        if (Process32First(hSnap, &pe)) {
            do {
                if (pe.th32ProcessID == pidP1) {
                    exists = true;
                    break;
                }
            } while (Process32Next(hSnap, &pe));
        }
        CloseHandle(hSnap);
    }

    if (exists)
        printf("Procesul P1.exe cu PID %lu inca exista!\n", pidP1);
    else
        printf("Procesul P1.exe cu PID %lu nu mai exista.\n", pidP1);

    CloseHandle(pi1.hThread);
    CloseHandle(pi1.hProcess);
    CloseHandle(pi2.hThread);
    CloseHandle(pi2.hProcess);

    createSummary(pids);

    UnmapViewOfFile(sharedVirtualMem);
    CloseHandle(sharedMemoryH);

    printf("P3 s-a terminat cu succes.\n");
}

int main() {
    P3_main();
    return 0;
}
