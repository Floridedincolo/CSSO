﻿// P2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <windows.h>
#include <algorithm>
#include <stdio.h>
#include <string.h>
#include<map>
#include<string>
#include<vector>
#include <tlhelp32.h>
#include<winver.h>
#pragma comment(lib, "version.lib")
#include <bcrypt.h>
#pragma comment(lib, "bcrypt.lib")
#define _CRT_SECURE_NO_WARNINGS
#define MAX_SIZE 1024
using namespace std;
map<string, int>extensionsMap;
vector<string> allowedExtensions = { ".exe", ".com", ".bat", ".cmd", ".ps1", ".vbs", ".js", ".msc" };
vector<string> files;
vector<int>pids;
vector<HANDLE>threads;
struct ThreadArgs {
    DWORD pid;
    char outputPath[MAX_SIZE];
};
void createDirectories(const char* fullPath) {
    char auxPath[MAX_SIZE];
    char currentPath[MAX_SIZE] = "";
    strcpy(auxPath, fullPath);

    char* p = strtok(auxPath, "\\");
    while (p != NULL) {
        strcat(currentPath, p);

        // Creeaz directorul doar daca nu exista deja
        if (!CreateDirectoryA(currentPath, NULL)) {
            DWORD error = GetLastError();
            if (error != ERROR_ALREADY_EXISTS) {
                printf("Eroare la crearea directorului %s (eroare %lu)\n", currentPath, error);
                return;
            }
        }

        strcat(currentPath, "\\");
        p = strtok(NULL, "\\");
    }
}

void F2(char* path, int pid) {
    HANDLE fh = CreateFileA(path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (fh == INVALID_HANDLE_VALUE) {
        printf("Eroare la crearea fisierului %s (%lu)\n", path, GetLastError());
        exit(1);
    }
    HANDLE processH = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, pid);
    if (processH == INVALID_HANDLE_VALUE) { 
        if(GetLastError()!=299)
        printf("CreateToolhelp32Snapshot failed.err = %d \n", GetLastError()); exit(-1); }
    MODULEENTRY32 moduleI;
    moduleI.dwSize = sizeof(MODULEENTRY32);
    BOOL valid = Module32First(processH, &moduleI);
    if (valid == 0) {
        printf("Process32First failed. err = %d \n", GetLastError()); CloseHandle(processH);
        exit(-1);
    }
    char buffer[MAX_SIZE];
    DWORD bytesWritten;
    do {
        sprintf(buffer, "%d %d %s %s\n", moduleI.th32ModuleID, moduleI.th32ProcessID, moduleI.szModule, moduleI.szExePath);
        WriteFile(fh, buffer, strlen(buffer), &bytesWritten, 0);
    } while (Module32Next(processH, &moduleI));

    HANDLE hSnapThreads = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
    if (hSnapThreads != INVALID_HANDLE_VALUE) {
        THREADENTRY32 te;
        te.dwSize = sizeof(THREADENTRY32);
        if (Thread32First(hSnapThreads, &te)) {
            do {
                if (te.th32OwnerProcessID == pid) {
                    sprintf(buffer, "THREAD: %lu %lu\n", te.th32ThreadID, te.th32OwnerProcessID);
                    WriteFile(fh, buffer, strlen(buffer), &bytesWritten, NULL);
                }
            } while (Thread32Next(hSnapThreads, &te));
        }
        CloseHandle(hSnapThreads);
    }
    CloseHandle(processH);
    CloseHandle(fh);
}
void getPids(char* path) {
    HANDLE fh = CreateFileA(path, GENERIC_READ, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (fh == INVALID_HANDLE_VALUE) {
        printf("Eroare la deschiderea fisierului %s (%lu)\n", path, GetLastError());
        exit(1);
    }
    char ch;
    DWORD bytesRead;
    ReadFile(fh, &ch, 1, &bytesRead, 0);
    int nr = 0;
    bool inNumber = false;
    while (bytesRead > 0) {
        if (inNumber == true) {
            if (ch >= '0' && ch <= '9')
                nr = nr * 10 + ch - '0';
            else {
                pids.push_back(nr);
                nr = 0;
                inNumber = false;
            }
        }
        else {
            if (ch == '=')
                inNumber = true;
        }
        if (ReadFile(fh, &ch, 1, &bytesRead, 0) == false)
            break;

    }

}
DWORD WINAPI F2Thread(LPVOID param) {
    ThreadArgs* args = (ThreadArgs*)param;
    F2(args->outputPath, args->pid);
    delete args;
    return 0;
}

void P2_main() {
    char filePath[MAX_SIZE] = "C:\\Facultate\\CSSO\\Laboratoare\\H3\\procese.txt";
    getPids(filePath);
    sort(pids.begin(), pids.end(), greater<int>());
    createDirectories("C:\\Facultate\\CSSO\\Laboratoare\\H3\\Detalii");
    char moduleFilePath[MAX_SIZE];
    /* sprintf(moduleFilePath, "%s\\module.txt", path);
     F2(moduleFilePath,0);*/

    for (int i = 0; i < min(5, pids.size()); i++)
    {
        sprintf(moduleFilePath, "C:\\Facultate\\CSSO\\Laboratoare\\H3\\Detalii\\%d.txt", pids[i]);
        ThreadArgs* args = new ThreadArgs();
        args->pid = pids[i];
        HANDLE hThread = CreateThread(NULL, 0, F2Thread, args, 0, NULL);
        if (hThread != NULL) {
            threads.push_back(hThread);
        }
        else {
            printf("Eroare la crearea threadului pentru PID %d (%lu)\n", pids[i], GetLastError());
            delete args;
        }        strcpy(args->outputPath, moduleFilePath);
    }
    if (!threads.empty()) {
        WaitForMultipleObjects((DWORD)threads.size(), threads.data(), TRUE, INFINITE);
        for (HANDLE h : threads) {
            CloseHandle(h);
        }
    }
    HANDLE sharedMemoryH = OpenFileMappingA(FILE_MAP_ALL_ACCESS, FALSE, "CSSOH3");
    if (!sharedMemoryH) {
        printf("Nu am putut deschide memory mapping (%lu)\n", GetLastError());
        return;
    }
    char* sharedVirtualMem = (char*)MapViewOfFile(sharedMemoryH, FILE_MAP_ALL_ACCESS, 0, 0, 0);
    if (!sharedVirtualMem) {
        printf("p2 nu pot mapa memoria (%lu)\n", GetLastError());
        CloseHandle(sharedMemoryH);
        return;
    }
    sharedVirtualMem[0] = 'X';
    char* p = sharedVirtualMem + 1;
    for (int i = 0; i <5 &&i<pids.size();i++)
        p += sprintf(p, "%d ", pids[i]);
    *p = ' ';
    UnmapViewOfFile(sharedVirtualMem);
    CloseHandle(sharedMemoryH);
}
int main()
{
    P2_main();
}
