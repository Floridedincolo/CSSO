﻿#include <windows.h>
#include <tlhelp32.h>
#include <stdio.h>

#define MAX_SIZE 1024

void createDirectories(const char* fullPath) {
    char auxPath[MAX_SIZE];
    char currentPath[MAX_SIZE] = "";
    strcpy(auxPath, fullPath);
    char* p = strtok(auxPath, "\\");
    while (p != NULL) {
        strcat(currentPath, p);
        CreateDirectoryA(currentPath, NULL);
        strcat(currentPath, "\\");
        p = strtok(NULL, "\\");
    }
}

void F1(char* path) {
    HANDLE fh = CreateFileA(path, GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (fh == INVALID_HANDLE_VALUE) return;

    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    PROCESSENTRY32 pe; pe.dwSize = sizeof(pe);
    if (Process32First(hSnap, &pe)) {
        DWORD written;
        char buffer[512];
        do {
            sprintf(buffer, "Process Id=%d %d %s CntThreads#%d\n" ,pe.th32ProcessID,pe.th32ParentProcessID, pe.szExeFile,pe.cntThreads);
            WriteFile(fh, buffer, strlen(buffer), &written, NULL);
        } while (Process32Next(hSnap, &pe));
    }

    CloseHandle(hSnap);
    CloseHandle(fh);
}

int main() {
    const char* dir = "C:\\Facultate\\CSSO\\Laboratoare\\H3";
    createDirectories(dir);

    char filePath[MAX_SIZE];
    sprintf(filePath, "%s\\procese.txt", dir);
    F1(filePath);

    return 0;
}
